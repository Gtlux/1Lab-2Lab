package com.foodbooking.controller;

import com.foodbooking.dao.CancellationRequestDAO;
import com.foodbooking.dao.OrderDAO;
import com.foodbooking.dao.RestaurantDAO;
import com.foodbooking.dao.UserDAO;
import com.foodbooking.model.CancellationRequest;
import com.foodbooking.model.Order;
import com.foodbooking.model.OrderStatus;
import com.foodbooking.model.Restaurant;
import com.foodbooking.model.User;
import com.foodbooking.model.UserRole;
import com.foodbooking.util.AlertHelper;
import com.foodbooking.util.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class OrdersTabController implements Initializable {

    @FXML
    private TableView<Order> ordersTable;

    @FXML
    private TableColumn<Order, Integer> idColumn;

    @FXML
    private TableColumn<Order, String> clientColumn;

    @FXML
    private TableColumn<Order, String> restaurantColumn;

    @FXML
    private TableColumn<Order, String> driverColumn;

    @FXML
    private TableColumn<Order, OrderStatus> statusColumn;

    @FXML
    private TableColumn<Order, BigDecimal> totalAmountColumn;

    @FXML
    private TableColumn<Order, String> deliveryAddressColumn;

    @FXML
    private TableColumn<Order, LocalDateTime> createdAtColumn;

    @FXML
    private Button addButton;

    @FXML
    private Button changeStatusButton;

    @FXML
    private Button assignDriverButton;

    @FXML
    private Button requestCancellationButton;

    @FXML
    private Button deleteButton;

    private OrderDAO orderDAO = new OrderDAO();
    private RestaurantDAO restaurantDAO = new RestaurantDAO();
    private CancellationRequestDAO cancellationRequestDAO = new CancellationRequestDAO();
    private UserDAO userDAO = new UserDAO();
    private ObservableList<Order> ordersList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        clientColumn.setCellValueFactory(new PropertyValueFactory<>("clientName"));
        restaurantColumn.setCellValueFactory(new PropertyValueFactory<>("restaurantName"));
        driverColumn.setCellValueFactory(new PropertyValueFactory<>("driverName"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        totalAmountColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        deliveryAddressColumn.setCellValueFactory(new PropertyValueFactory<>("deliveryAddress"));
        createdAtColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

        if (SessionManager.getInstance().isClient()) {
            deleteButton.setVisible(false);
            deleteButton.setManaged(false);
            changeStatusButton.setVisible(false);
            changeStatusButton.setManaged(false);
            assignDriverButton.setVisible(false);
            assignDriverButton.setManaged(false);
            requestCancellationButton.setVisible(true);
            requestCancellationButton.setManaged(true);
        } else if (SessionManager.getInstance().isRestaurantOwner() || SessionManager.getInstance().isAdministrator()) {
            addButton.setVisible(false);
            addButton.setManaged(false);
            requestCancellationButton.setVisible(false);
            requestCancellationButton.setManaged(false);
            assignDriverButton.setVisible(true);
            assignDriverButton.setManaged(true);
        } else {
            addButton.setVisible(false);
            addButton.setManaged(false);
            requestCancellationButton.setVisible(false);
            requestCancellationButton.setManaged(false);
            assignDriverButton.setVisible(false);
            assignDriverButton.setManaged(false);
        }

        loadOrders();
    }

    private void loadOrders() {
        try {
            List<Order> orders = new ArrayList<>();

            if (SessionManager.getInstance().isClient()) {
                orders = orderDAO.getOrdersByClientId(SessionManager.getInstance().getCurrentUser().getId());
            } else if (SessionManager.getInstance().isRestaurantOwner()) {
                List<Restaurant> ownRestaurants = restaurantDAO.getRestaurantsByOwnerId(
                        SessionManager.getInstance().getCurrentUser().getId());
                for (Restaurant restaurant : ownRestaurants) {
                    orders.addAll(orderDAO.getOrdersByRestaurantId(restaurant.getId()));
                }
            } else if (SessionManager.getInstance().isDriver()) {
                orders.addAll(orderDAO.getAvailableOrdersForDrivers());
                orders.addAll(orderDAO.getOrdersByDriverId(SessionManager.getInstance().getCurrentUser().getId()));
            } else if (SessionManager.getInstance().isAdministrator()) {
                orders = orderDAO.getAllOrders();
            }

            ordersList.clear();
            ordersList.addAll(orders);
            ordersTable.setItems(ordersList);
        } catch (Exception e) {
            e.printStackTrace();
            AlertHelper.showError("Klaida", "Nepavyko užkrauti užsakymų: " + e.getMessage());
        }
    }

    @FXML
    private void handleAdd() {
        if (!SessionManager.getInstance().isClient() && !SessionManager.getInstance().isAdministrator()) {
            AlertHelper.showError("Klaida", "Tik klientai gali kurti užsakymus!");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/OrderDialog.fxml"));
            Parent root = loader.load();

            OrderDialogController controller = loader.getController();

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Naujas užsakymas");
            stage.setScene(new Scene(root));
            stage.showAndWait();

            if (controller.isSaved()) {
                loadOrders();
            }
        } catch (Exception e) {
            e.printStackTrace();
            AlertHelper.showError("Klaida", "Nepavyko atidaryti dialogo: " + e.getMessage());
        }
    }

    @FXML
    private void handleView() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning("Įspėjimas", "Pasirinkite užsakymą peržiūrai!");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/OrderViewDialog.fxml"));
            Parent root = loader.load();

            OrderViewDialogController controller = loader.getController();
            controller.setOrder(selected);

            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Užsakymo informacija");
            stage.setScene(new Scene(root));
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
            AlertHelper.showError("Klaida", "Nepavyko atidaryti dialogo: " + e.getMessage());
        }
    }

    @FXML
    private void handleChangeStatus() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning("Įspėjimas", "Pasirinkite užsakymą!");
            return;
        }

        if (SessionManager.getInstance().isClient() &&
            !selected.getClientId().equals(SessionManager.getInstance().getCurrentUser().getId())) {
            AlertHelper.showError("Klaida", "Galite keisti tik savo užsakymų statusą!");
            return;
        }

        if (SessionManager.getInstance().isRestaurantOwner()) {
            Restaurant restaurant = restaurantDAO.getRestaurantById(selected.getRestaurantId());
            if (restaurant == null || !restaurant.getOwnerId().equals(
                    SessionManager.getInstance().getCurrentUser().getId())) {
                AlertHelper.showError("Klaida", "Galite keisti tik savo restorano užsakymų statusą!");
                return;
            }
        }

        ChoiceDialog<OrderStatus> dialog = new ChoiceDialog<>(selected.getStatus(), OrderStatus.values());
        dialog.setTitle("Keisti užsakymo statusą");
        dialog.setHeaderText("Pasirinkite naują statusą");
        dialog.setContentText("Statusas:");

        dialog.showAndWait().ifPresent(newStatus -> {
            if (newStatus == OrderStatus.PICKED_UP && SessionManager.getInstance().isDriver()) {
                if (orderDAO.assignDriver(selected.getId(), SessionManager.getInstance().getCurrentUser().getId())) {
                    AlertHelper.showSuccess("Sėkmė", "Užsakymas priskirtas jums!");
                    loadOrders();
                } else {
                    AlertHelper.showError("Klaida", "Nepavyko priskirti užsakymo!");
                }
            } else {
                selected.updateStatus(newStatus);
                if (orderDAO.updateOrder(selected)) {
                    AlertHelper.showSuccess("Sėkmė", "Užsakymo statusas pakeistas!");
                    loadOrders();
                } else {
                    AlertHelper.showError("Klaida", "Nepavyko pakeisti statuso!");
                }
            }
        });
    }

    @FXML
    private void handleDelete() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning("Įspėjimas", "Pasirinkite užsakymą šalinimui!");
            return;
        }

        if (SessionManager.getInstance().isAdministrator()) {
        } else if (SessionManager.getInstance().isRestaurantOwner()) {
            if (selected.getStatus() != OrderStatus.CANCELLED) {
                AlertHelper.showError("Klaida",
                    "Galite trinti tik atšauktus užsakymus!\n\n" +
                    "Dabartinis statusas: " + selected.getStatus().getDisplayName());
                return;
            }

            Restaurant restaurant = restaurantDAO.getRestaurantById(selected.getRestaurantId());
            if (restaurant == null || !restaurant.getOwnerId().equals(
                    SessionManager.getInstance().getCurrentUser().getId())) {
                AlertHelper.showError("Klaida", "Galite trinti tik savo restorano užsakymus!");
                return;
            }
        } else {
            AlertHelper.showError("Klaida", "Neturite teisės trinti užsakymų!");
            return;
        }

        if (AlertHelper.showConfirmation("Patvirtinimas",
                String.format("Ar tikrai norite ištrinti užsakymą #%d?\n\nRestoranas: %s\nSuma: %.2f €",
                    selected.getId(), selected.getRestaurantName(), selected.getTotalAmount()))) {
            try {
                if (orderDAO.deleteOrder(selected.getId())) {
                    AlertHelper.showSuccess("Sėkmė", "Užsakymas sėkmingai ištrintas!");
                    loadOrders();
                } else {
                    AlertHelper.showError("Klaida", "Nepavyko ištrinti užsakymo!");
                }
            } catch (Exception e) {
                e.printStackTrace();
                AlertHelper.showError("Klaida", "Šalinimo klaida: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleRequestCancellation() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning("Įspėjimas", "Pasirinkite užsakymą atšaukimui!");
            return;
        }

        if (!SessionManager.getInstance().isClient() ||
            !selected.getClientId().equals(SessionManager.getInstance().getCurrentUser().getId())) {
            AlertHelper.showError("Klaida", "Galite atšaukti tik savo užsakymus!");
            return;
        }

        if (selected.getStatus() == OrderStatus.DELIVERED || selected.getStatus() == OrderStatus.CANCELLED) {
            AlertHelper.showError("Klaida", "Negalima atšaukti jau pristatyto arba atšaukto užsakymo!");
            return;
        }

        CancellationRequest existingRequest = cancellationRequestDAO.getCancellationRequestByOrderId(selected.getId());
        if (existingRequest != null && existingRequest.getStatus() == CancellationRequest.CancellationStatus.PENDING) {
            AlertHelper.showWarning("Įspėjimas",
                "Šio užsakymo atšaukimo užklausa jau pateikta!\n\n" +
                "Statusas: Laukiama restorano savininko patvirtinimo");
            return;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Atšaukimo užklausa");
        dialog.setHeaderText("Prašome nurodyti atšaukimo priežastį");
        dialog.setContentText("Priežastis:");

        dialog.showAndWait().ifPresent(reason -> {
            if (reason.trim().isEmpty()) {
                AlertHelper.showError("Klaida", "Prašome nurodyti atšaukimo priežastį!");
                return;
            }

            String confirmMessage = String.format(
                "Ar tikrai norite pateikti užsakymo #%d atšaukimo užklausą?\n\n" +
                "Priežastis: %s\n\n" +
                "Restorano savininkas peržiūrės ir priims sprendimą.",
                selected.getId(), reason
            );

            if (AlertHelper.showConfirmation("Patvirtinimas", confirmMessage)) {
                CancellationRequest request = new CancellationRequest(
                    selected.getId(),
                    SessionManager.getInstance().getCurrentUser().getId(),
                    reason.trim()
                );

                int requestId = cancellationRequestDAO.createCancellationRequest(request);
                if (requestId > 0) {
                    AlertHelper.showSuccess("Sėkmė",
                        "Atšaukimo užklausa sėkmingai pateikta!\n\n" +
                        "Užklausa #" + requestId + "\n" +
                        "Restorano savininkas gaus pranešimą ir priims sprendimą.\n\n" +
                        "Galite stebėti užklausos statusą užsakymų sąraše.");
                    loadOrders();
                } else {
                    AlertHelper.showError("Klaida", "Nepavyko pateikti atšaukimo užklausos!");
                }
            }
        });
    }

    @FXML
    private void handleAssignDriver() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertHelper.showWarning("Įspėjimas", "Pasirinkite užsakymą vairuotojo priskyrimui!");
            return;
        }

        if (selected.getStatus() == OrderStatus.CANCELLED || selected.getStatus() == OrderStatus.DELIVERED) {
            AlertHelper.showError("Klaida", "Negalima priskirti vairuotojo atšauktam arba pristatytam užsakymui!");
            return;
        }

        List<User> drivers = userDAO.getUsersByRole(UserRole.DRIVER);
        if (drivers.isEmpty()) {
            AlertHelper.showError("Klaida", "Sistemoje nėra registruotų vairuotojų!");
            return;
        }

        java.util.Map<String, User> driverMap = new java.util.HashMap<>();
        List<String> driverNames = new java.util.ArrayList<>();
        for (User driver : drivers) {
            String displayName = driver.getFullName() + " (" + driver.getPhoneNumber() + ")";
            driverMap.put(displayName, driver);
            driverNames.add(displayName);
        }

        ChoiceDialog<String> dialog = new ChoiceDialog<>(null, driverNames);
        dialog.setTitle("Priskirti vairuotoją");
        dialog.setHeaderText(String.format("Priskirti vairuotoją užsakymui #%d\n\nRestoranas: %s\nAdresas: %s",
            selected.getId(),
            selected.getRestaurantName(),
            selected.getDeliveryAddress()));
        dialog.setContentText("Pasirinkite vairuotoją:");

        dialog.showAndWait().ifPresent(selectedDriverName -> {
            User driver = driverMap.get(selectedDriverName);
            if (driver == null) {
                AlertHelper.showError("Klaida", "Nepavyko rasti pasirinkto vairuotojo!");
                return;
            }

            if (orderDAO.assignDriver(selected.getId(), driver.getId())) {
                OrderStatus newStatus = selected.getStatus() == OrderStatus.PENDING ? OrderStatus.CONFIRMED : OrderStatus.READY;
                selected.updateStatus(newStatus);
                orderDAO.updateOrder(selected);

                AlertHelper.showSuccess("Sėkmė",
                    String.format("Vairuotojas %s priskirtas užsakymui #%d!\n\n" +
                        "Vairuotojas matys užsakymą savo sąraše.",
                        driver.getFullName(), selected.getId()));
                loadOrders();
            } else {
                AlertHelper.showError("Klaida", "Nepavyko priskirti vairuotojo!");
            }
        });
    }

    @FXML
    private void handleRefresh() {
        loadOrders();
    }
}
